/**
 * 
 */
/**
 * 
 */
module stringManipulation {
}