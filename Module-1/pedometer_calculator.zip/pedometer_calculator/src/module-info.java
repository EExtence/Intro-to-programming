/**
 * 
 */
/**
 * 
 */
module pedometer_calculator {
}