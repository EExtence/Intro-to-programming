/**
 * 
 */
/**
 * 
 */
module rockPaperScissors {
}