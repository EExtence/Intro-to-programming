/**
 * 
 */
/**
 * 
 */
module palindromicSwag {
}