/**
 * 
 */
/**
 * 
 */
module dice {
}